# LifeBmx — protótipo Android

Aplicativo demonstrativo para BMX Race, com visual escuro, verde neon e navegação inspirada nas referências enviadas.

## O que funciona nesta versão
- Início e metas semanais
- Biblioteca de treinos de gate, sprint, curvas, pumping, controle, físico e leitura de corrida
- Checklist de sessão e registro de treino
- Histórico e gráficos simples de consistência
- Perfil editável salvo localmente
- Clube demonstrativo
- Coach demonstrativo com respostas predefinidas

## Limitações importantes
Este é um protótipo local: não tem login real, nuvem, comunidade online, notificações, sincronização, nem IA conectada. Os dados ficam no armazenamento local do WebView. O app não substitui um treinador presencial.

## Como gerar o APK
1. Instale o Android Studio no computador.
2. Abra a pasta `LifeBmx_Android` usando **Open**.
3. Aguarde o Gradle sincronizar. Se solicitado, instale Android SDK Platform 35.
4. Use **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de debug normalmente fica em `app/build/outputs/apk/debug/app-debug.apk`.

## Testar sem compilar
Abra `app/src/main/assets/index.html` em um navegador moderno. A experiência foi desenhada para telas de celular.

## Requisitos
Android Studio recente, JDK compatível com o Gradle do Android Studio e conexão à internet na primeira sincronização.
